{
    "version": "1.7",
    "octreeDir": "data",
    "projection": "",
    "points": 121291,
    "boundingBox": {
        "lx": -77.28700256347656,
        "ly": -67.54900360107422,
        "lz": -9.5649995803833,
        "ux": 78.69300079345703,
        "uy": 88.43099975585938,
        "uz": 146.4150037765503
    },
    "tightBoundingBox": {
        "lx": -77.28700256347656,
        "ly": -67.54900360107422,
        "lz": -9.5649995803833,
        "ux": 78.69300079345703,
        "uy": 55.486000061035159,
        "uz": 2.7839999198913576
    },
    "pointAttributes": [
        "POSITION_CARTESIAN",
        "COLOR_PACKED"
    ],
    "spacing": 1.3508265018463135,
    "scale": 0.001,
    "hierarchyStepSize": 5
}