{
    "version": "1.7",
    "octreeDir": "data",
    "projection": "",
    "points": 119620,
    "boundingBox": {
        "lx": -78.92500305175781,
        "ly": -79.6760025024414,
        "lz": -26.165000915527345,
        "ux": 79.63800048828125,
        "uy": 78.88700103759766,
        "uz": 132.39800262451173
    },
    "tightBoundingBox": {
        "lx": -78.92500305175781,
        "ly": -79.6760025024414,
        "lz": -26.165000915527345,
        "ux": 78.45800018310547,
        "uy": 78.88700103759766,
        "uz": 2.884000062942505
    },
    "pointAttributes": [
        "POSITION_CARTESIAN",
        "COLOR_PACKED"
    ],
    "spacing": 1.3731958866119385,
    "scale": 0.001,
    "hierarchyStepSize": 5
}